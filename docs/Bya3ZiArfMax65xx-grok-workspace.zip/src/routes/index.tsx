import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import { Hud } from "@/floorplan/App";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [Stage, setStage] = useState<ComponentType | null>(null);
  useEffect(() => {
    let dead = false;
    void import("@/floorplan/stage").then((mod) => {
      if (!dead) setStage(() => mod.Stage);
    });
    return () => {
      dead = true;
    };
  }, []);
  return (
    <div className="relative h-dvh overflow-hidden bg-paper text-ink">
      <div className="absolute inset-0 touch-none bg-paper">{Stage ? <Stage /> : null}</div>
      <Hud />
    </div>
  );
}
