//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CmDb-882.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CU5YC1lB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CU5YC1lB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DvciQNp0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
