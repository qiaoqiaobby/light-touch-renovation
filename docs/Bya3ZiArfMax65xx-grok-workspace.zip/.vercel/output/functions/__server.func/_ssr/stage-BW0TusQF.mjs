import { i as __toESM } from "../_runtime.mjs";
import { a as useThree, c as Raycaster, d as Vector2, f as Vector3, g as require_react, h as require_jsx_runtime, i as useFrame, l as Shape, n as Edges, o as CanvasTexture, r as Canvas, s as Color, t as OrbitControls, u as ShapeGeometry } from "../_libs/@react-three/drei+[...].mjs";
import { a as wx, c as CEILING, d as FURNITURE, f as ROOMS, i as walls, l as DOORS, n as collidersFrom, o as wz, p as SPAWN, r as doorMotion, s as usePlan, u as EYE } from "./routes-DN_CnaDq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stage-BW0TusQF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Mat({ color, roughness = .78, metalness = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
		color,
		roughness,
		metalness
	});
}
function Bed({ w, d, color }) {
	const pillows = w > 1.35 ? 2 : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.16,
				.02
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.28,
				d * .94
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#8d7258",
				roughness: .62
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.36,
				.04
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .94,
				.16,
				d * .86
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#f3f0ea",
				roughness: .92
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.58,
				-d / 2 + .045
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				1.02,
				.08
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .86
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.48,
				d * .08
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .96,
				.08,
				d * .55
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .94
			})]
		}),
		Array.from({ length: pillows }, (_, i) => {
			const span = w * .78;
			const pw = span / pillows - .04;
			const x = -span / 2 + pw / 2 + i * (span / pillows);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					.5,
					-d / 2 + .32
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					pw,
					.12,
					.36
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
					color: "#f7f4ee",
					roughness: .9
				})]
			}, i);
		})
	] });
}
function Wardrobe({ w, d, color }) {
	const n = Math.max(2, Math.round(w / .55));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			1.1,
			0
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w,
			2.2,
			d
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: .58
		})]
	}), Array.from({ length: n - 1 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			-w / 2 + (i + 1) * w / n,
			1.12,
			d / 2 + .004
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			.012,
			2,
			.008
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#c3b7a4",
			roughness: .5
		})]
	}, i))] });
}
function Desk({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.74,
			0
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w,
			.04,
			d
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: .55
		})]
	}), [
		[-1, -1],
		[1, -1],
		[-1, 1],
		[1, 1]
	].map(([sx, sz], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			sx * (w / 2 - .06),
			.36,
			sz * (d / 2 - .06)
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			.05,
			.72,
			.05
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#6e5844",
			roughness: .6
		})]
	}, i))] });
}
function Chair({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.46,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .86,
				.05,
				d * .86
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, { color })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.72,
				-d / 2 + .05
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .86,
				.42,
				.05
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, { color })]
		}),
		[
			[-1, -1],
			[1, -1],
			[-1, 1],
			[1, 1]
		].map(([sx, sz], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				sx * (w / 2 - .06),
				.22,
				sz * (d / 2 - .06)
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.04,
				.44,
				.04
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#5c4a3a",
				roughness: .55
			})]
		}, i))
	] });
}
function Sofa({ w, d, color }) {
	const arm = Math.min(.18, w * .12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.28,
				.04
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.28,
				d * .92
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .9
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.52,
				-d / 2 + .12
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.42,
				.2
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .9
			})]
		}),
		[-1, 1].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				s * (w / 2 - arm / 2),
				.46,
				.02
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				arm,
				.36,
				d * .9
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .9
			})]
		}, s))
	] });
}
function Table({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.74,
			0
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w,
			.045,
			d
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: .5
		})]
	}), [
		[-1, -1],
		[1, -1],
		[-1, 1],
		[1, 1]
	].map(([sx, sz], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			sx * (w / 2 - .08),
			.36,
			sz * (d / 2 - .08)
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			.06,
			.72,
			.06
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#6a5340",
			roughness: .55
		})]
	}, i))] });
}
function Coffee({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.32,
			0
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w,
			.08,
			d
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: .45
		})]
	});
}
function TvStand({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.28,
				0
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.48,
				d
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .55
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.86,
				d / 2 - .03
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				Math.min(w * .72, 1.45),
				.78,
				.04
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#1c252b",
				roughness: .35,
				metalness: .2
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.86,
				d / 2 - .008
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				Math.min(w * .68, 1.38),
				.7,
				.01
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#243044",
				roughness: .15,
				metalness: .05,
				emissive: "#1a3350",
				emissiveIntensity: .35
			})]
		})
	] });
}
function Rug({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.012,
			0
		],
		receiveShadow: true,
		rotation: [
			-Math.PI / 2,
			0,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [w, d] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: 1
		})]
	});
}
function Plant() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.16,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.16,
				.13,
				.28,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#d9d2c6",
				roughness: .7
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.55,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.28,
				16,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#6f9a5c",
				roughness: .85
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.12,
				.72,
				.05
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.16,
				12,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#86aa68",
				roughness: .85
			})]
		})
	] });
}
function Toilet() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.22,
			.06
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			.38,
			.36,
			.5
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#f4f6f7",
			roughness: .35
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.42,
			-.18
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			.36,
			.32,
			.16
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#f4f6f7",
			roughness: .35
		})]
	})] });
}
function Vanity({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.42,
				0
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.8,
				d
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .55
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.84,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .42,
				.06,
				d * .55
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#f7f8f8",
				roughness: .25
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.25,
				-d / 2 + .02
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .7,
				.55,
				.02
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#d5dee6",
				metalness: .75,
				roughness: .12
			})]
		})
	] });
}
function GlassMat() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
		color: "#c5d5de",
		transparent: true,
		opacity: .32,
		roughness: .05,
		metalness: .1,
		depthWrite: false
	});
}
function Shower({ w, d }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.04,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.06,
				d
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#d7e0e2",
				roughness: .4
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1,
				-d / 2
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				1.9,
				.02
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlassMat, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				w / 2,
				1,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.02,
				1.9,
				d
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlassMat, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-w / 2,
				1,
				d * .18
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.02,
				1.9,
				d * .64
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlassMat, {})]
		})
	] });
}
function Counter({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.43,
				.03
			],
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.78,
				d - .06
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .62
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.84,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w,
				.04,
				d
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#f3f0ea",
				roughness: .4
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-w * .28,
				.88,
				.02
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.55,
				.03,
				.38
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#c5ced4",
				metalness: .45,
				roughness: .28
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				w * .12,
				.88,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.7,
				.02,
				.4
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color: "#2a2e32",
				roughness: .4,
				metalness: .3
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.55,
				-d / 2 + .18
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				w * .62,
				.62,
				.34
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
				color,
				roughness: .58
			})]
		})
	] });
}
function Fridge({ w, d, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			.9,
			0
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w,
			1.78,
			d
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color,
			roughness: .35,
			metalness: .12
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			1.15,
			d / 2 + .004
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			w * .9,
			.012,
			.008
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mat, {
			color: "#9aa3a8",
			metalness: .3,
			roughness: .4
		})]
	})] });
}
function Piece({ f }) {
	const w = f.w / 1e3;
	const d = f.d / 1e3;
	const body = (() => {
		switch (f.type) {
			case "bed": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bed, {
				w,
				d,
				color: f.color
			});
			case "wardrobe": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wardrobe, {
				w,
				d,
				color: f.color
			});
			case "desk": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {
				w,
				d,
				color: f.color
			});
			case "chair": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chair, {
				w,
				d,
				color: f.color
			});
			case "sofa": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sofa, {
				w,
				d,
				color: f.color
			});
			case "table": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
				w,
				d,
				color: f.color
			});
			case "coffeetable": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coffee, {
				w,
				d,
				color: f.color
			});
			case "tvstand": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TvStand, {
				w,
				d,
				color: f.color
			});
			case "rug": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rug, {
				w,
				d,
				color: f.color
			});
			case "plant": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plant, {});
			case "toilet": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toilet, {});
			case "vanity": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vanity, {
				w,
				d,
				color: f.color
			});
			case "shower": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shower, {
				w,
				d
			});
			case "counter": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
				w,
				d,
				color: f.color
			});
			case "fridge": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fridge, {
				w,
				d,
				color: f.color
			});
			default: return null;
		}
	})();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		position: [
			wx(f.cx),
			0,
			wz(f.cy)
		],
		rotation: [
			0,
			-f.rot * Math.PI / 180,
			0
		],
		children: body
	});
}
function Furniture() {
	const on = usePlan((s) => s.furniture);
	const items = (0, import_react.useMemo)(() => FURNITURE, []);
	if (!on) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: items.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Piece, { f }, f.id)) });
}
var LABEL = {
	A: [3814, 2700],
	B: [2500, 6100],
	C: [4060, 9100],
	Bath: [3800, 11240],
	K: [9600, 11600],
	L: [7300, 9600]
};
function shapeGeo(poly, ceiling) {
	const s = new Shape();
	poly.forEach(([x, y], i) => {
		const X = wx(x);
		const Y = ceiling ? wz(y) : -wz(y);
		if (i === 0) s.moveTo(X, Y);
		else s.lineTo(X, Y);
	});
	const g = new ShapeGeometry(s);
	g.rotateX(ceiling ? Math.PI / 2 : -Math.PI / 2);
	return g;
}
function Floor({ room }) {
	const geo = (0, import_react.useMemo)(() => shapeGeo(room.poly, false), [room]);
	const ceil = (0, import_react.useMemo)(() => shapeGeo(room.poly, true), [room]);
	(0, import_react.useEffect)(() => () => {
		geo.dispose();
		ceil.dispose();
	}, [geo, ceil]);
	const selected = usePlan((s) => s.selected === room.id);
	const showCeil = usePlan((s) => s.mode === "walk" || !s.section);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		geometry: geo,
		position: [
			0,
			.01,
			0
		],
		receiveShadow: true,
		onClick: (e) => {
			e.stopPropagation();
			usePlan.getState().select(room.id);
		},
		onDoubleClick: (e) => {
			e.stopPropagation();
			usePlan.getState().focusRoom(room.id);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: selected ? "#d4e3f3" : room.floor,
			roughness: .88
		})
	}), showCeil ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		geometry: ceil,
		position: [
			0,
			CEILING,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#f7f4ee",
			roughness: 1,
			side: 1
		})
	}) : null] });
}
function prism(axis, a0, a1, f0, f1, y0, y1) {
	const x0 = wx(axis === "h" ? a0 : f0);
	const x1 = wx(axis === "h" ? a1 : f1);
	const z0 = wz(axis === "h" ? f0 : a0);
	const z1 = wz(axis === "h" ? f1 : a1);
	return {
		position: [
			(x0 + x1) / 2,
			(y0 + y1) / 2,
			(z0 + z1) / 2
		],
		args: [
			Math.max(Math.abs(x1 - x0), .012),
			Math.max(y1 - y0, .012),
			Math.max(Math.abs(z1 - z0), .012)
		]
	};
}
function WallSolid({ wall, height }) {
	const cuts = [...wall.openings].sort((a, b) => a.a0 - b.a0);
	const solids = [];
	const glasses = [];
	let cursor = wall.a0;
	for (const o of cuts) {
		const s0 = Math.max(o.a0, wall.a0);
		const s1 = Math.min(o.a1, wall.a1);
		if (s1 - s0 < 20) continue;
		if (s0 > cursor + 8) solids.push({
			a0: cursor,
			a1: s0,
			y0: 0,
			y1: height
		});
		const head = Math.min(o.head, height);
		const sill = Math.min(o.sill, head);
		if (sill > .02) solids.push({
			a0: s0,
			a1: s1,
			y0: 0,
			y1: sill
		});
		if (height > head + .02) solids.push({
			a0: s0,
			a1: s1,
			y0: head,
			y1: height
		});
		if (o.kind === "window" && head - sill > .08) glasses.push({
			a0: s0,
			a1: s1,
			y0: sill,
			y1: head
		});
		cursor = Math.max(cursor, s1);
	}
	if (wall.a1 > cursor + 8) solids.push({
		a0: cursor,
		a1: wall.a1,
		y0: 0,
		y1: height
	});
	const color = wall.kind === "ext" ? "#e4ddd0" : wall.kind === "stub" ? "#ddd6c8" : "#f4f1ea";
	const midF = (wall.f0 + wall.f1) / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [solids.map((s, i) => {
		const box = prism(wall.axis, s.a0, s.a1, wall.f0, wall.f1, s.y0, s.y1);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: box.position,
			castShadow: true,
			receiveShadow: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: box.args }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color,
					roughness: .92
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Edges, {
					threshold: 18,
					color: "#c4bdb0"
				})
			]
		}, i);
	}), glasses.map((g, i) => {
		const pane = prism(wall.axis, g.a0, g.a1, midF - 12, midF + 12, g.y0, g.y1);
		const length = (g.a1 - g.a0) / 1e3;
		const n = Math.max(1, Math.round(length / .9));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: pane.position,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: pane.args }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#b7c9d4",
				transparent: true,
				opacity: .38,
				roughness: .06,
				metalness: .12,
				depthWrite: false
			})]
		}), Array.from({ length: n + 1 }, (_, k) => {
			const along = g.a0 + (g.a1 - g.a0) * k / n;
			const bar = prism(wall.axis, along - 18, along + 18, midF - 28, midF + 28, g.y0, g.y1);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: bar.position,
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: bar.args }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#f7f4ee",
					roughness: .4
				})]
			}, k);
		})] }, `g${i}`);
	})] });
}
function SwingDoor({ door, height }) {
	const ref = (0, import_react.useRef)(null);
	const motion = (0, import_react.useMemo)(() => doorMotion(door), [door]);
	const amount = (0, import_react.useRef)(usePlan.getState().doors[door.id] ?? 0);
	useFrame((_, dt) => {
		const d = Math.min(dt, .05);
		const target = usePlan.getState().doors[door.id] ?? 0;
		amount.current += (target - amount.current) * Math.min(1, d * 7);
		if (ref.current) ref.current.rotation.y = motion.closed + (motion.open - motion.closed) * amount.current;
	});
	const leafH = Math.min(door.head - .04, height - .02);
	const leafL = door.width / 1e3;
	if (leafH < .2) return null;
	const toggle = (e) => {
		e.stopPropagation();
		usePlan.getState().toggleDoor(door.id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		position: [
			wx(motion.hinge[0]),
			0,
			wz(motion.hinge[1])
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				leafL / 2,
				leafH / 2,
				0
			],
			castShadow: true,
			userData: { doorId: door.id },
			onClick: toggle,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				leafL,
				leafH,
				.04
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: door.id === "M1" ? "#6b4e38" : "#efe4d4",
				roughness: .55
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				leafL - .08,
				Math.min(1, leafH - .08),
				.035
			],
			onClick: toggle,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.028,
				12,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#c6a15a",
				metalness: .65,
				roughness: .3
			})]
		})]
	});
}
function SlideDoor({ door, height }) {
	const ref = (0, import_react.useRef)(null);
	const amount = (0, import_react.useRef)(usePlan.getState().doors[door.id] ?? 0);
	useFrame((_, dt) => {
		const d = Math.min(dt, .05);
		const target = usePlan.getState().doors[door.id] ?? 0;
		amount.current += (target - amount.current) * Math.min(1, d * 7);
		const g = ref.current;
		if (!g) return;
		const span = door.width / 1e3;
		g.children.forEach((child, i) => {
			const base = i === 0 ? -span / 4 : span / 4;
			child.position.x = base + amount.current * span * .46;
		});
	});
	const leafH = Math.min(door.head - .05, height - .02);
	const panel = door.width / 1e3 * .52;
	if (leafH < .2) return null;
	const across = (door.w[0] + door.w[1]) / 2;
	const along = (door.j[0] + door.j[1]) / 2;
	const pos = door.axis === "h" ? [
		wx(along),
		0,
		wz(across)
	] : [
		wx(across),
		0,
		wz(along)
	];
	const rot = door.axis === "v" ? -Math.PI / 2 : 0;
	const toggle = (e) => {
		e.stopPropagation();
		usePlan.getState().toggleDoor(door.id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		position: pos,
		rotation: [
			0,
			rot,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref,
			children: [0, 1].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					leafH / 2,
					i === 0 ? .02 : -.02
				],
				userData: { doorId: door.id },
				onClick: toggle,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					panel,
					leafH,
					.02
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#d5e2ea",
					transparent: true,
					opacity: .55,
					roughness: .08,
					metalness: .15
				})]
			}, i))
		})
	});
}
function LabelSprite({ name, area, position }) {
	const [map, setMap] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let dead = false;
		const draw = () => {
			const c = document.createElement("canvas");
			c.width = 512;
			c.height = 256;
			const g = c.getContext("2d");
			if (!g) return;
			g.clearRect(0, 0, 512, 256);
			g.fillStyle = "rgba(246,243,236,0.92)";
			g.beginPath();
			g.roundRect(16, 28, 480, 200, 18);
			g.fill();
			g.fillStyle = "#1c252b";
			g.font = "600 72px \"Noto Serif SC\", serif";
			g.textAlign = "center";
			g.textBaseline = "middle";
			g.fillText(name, 256, 100);
			g.fillStyle = "#5c676e";
			g.font = "44px \"Noto Sans SC\", sans-serif";
			g.fillText(area, 256, 168);
			const tex = new CanvasTexture(c);
			tex.needsUpdate = true;
			if (!dead) setMap(tex);
		};
		Promise.all([document.fonts.load("600 72px \"Noto Serif SC\""), document.fonts.load("44px \"Noto Sans SC\"")]).then(draw);
		return () => {
			dead = true;
		};
	}, [name, area]);
	(0, import_react.useEffect)(() => () => map?.dispose(), [map]);
	if (!map) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
		position,
		scale: [
			1.7,
			.85,
			1
		],
		renderOrder: 2,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
			map,
			transparent: true,
			depthTest: false
		})
	});
}
function Labels({ height }) {
	if (!usePlan((s) => s.labels && s.mode !== "walk")) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: ROOMS.map((r) => {
		const at = LABEL[r.id];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabelSprite, {
			name: r.name,
			area: `${r.label} ㎡`,
			position: [
				wx(at[0]),
				height + .42,
				wz(at[1])
			]
		}, r.id);
	}) });
}
function House() {
	const built = (0, import_react.useMemo)(() => walls(), []);
	const section = usePlan((s) => s.section);
	const height = usePlan((s) => s.mode) === "walk" || !section ? CEILING : 1.15;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		ROOMS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floor, { room: r }, r.id)),
		built.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WallSolid, {
			wall: w,
			height
		}, w.id)),
		DOORS.map((d) => d.kind === "swing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwingDoor, {
			door: d,
			height
		}, d.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideDoor, {
			door: d,
			height
		}, d.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Furniture, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Labels, { height })
	] });
}
var _cols = collidersFrom(walls());
function blocked(x, z, r, doors) {
	for (const c of _cols) {
		if (x < c.x0 - r || x > c.x1 + r || z < c.z0 - r || z > c.z1 + r) continue;
		const hole = c.holes.find((h) => x > h.x0 - .04 && x < h.x1 + .04 && z > h.z0 - .04 && z < h.z1 + .04);
		if (hole && (doors[hole.id] ?? 0) > .42) continue;
		return true;
	}
	return false;
}
function sunPos(hour) {
	const t = (hour - 6) / 12;
	const az = Math.PI * (.18 + t * .68);
	const el = Math.sin(Math.PI * Math.min(1, Math.max(0, t))) * 1.05 + .18;
	return [
		Math.cos(az) * 16,
		Math.sin(el) * 18 + 3,
		-Math.sin(az) * 11
	];
}
function Lighting() {
	const night = usePlan((s) => s.night);
	const hour = usePlan((s) => s.hour);
	const { scene, gl } = useThree();
	(0, import_react.useEffect)(() => {
		const color = new Color(night ? "#15191f" : "#e4dfd4");
		scene.background = color;
		gl.setClearColor(color);
	}, [
		night,
		scene,
		gl
	]);
	const pos = sunPos(hour);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#f4efe4",
			"#c9c2b4",
			night ? .12 : .72
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: night ? .05 : .18 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: pos,
			intensity: night ? .08 : 1.7,
			castShadow: true,
			"shadow-mapSize-width": 2048,
			"shadow-mapSize-height": 2048,
			"shadow-camera-near": .5,
			"shadow-camera-far": 48,
			"shadow-camera-left": -14,
			"shadow-camera-right": 14,
			"shadow-camera-top": 14,
			"shadow-camera-bottom": -14,
			"shadow-bias": -35e-5,
			"shadow-normalBias": .035
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-8,
				6,
				-6
			],
			intensity: night ? .02 : .28,
			color: "#f3efe6"
		}),
		night ? ROOMS.map((r) => {
			const xs = r.poly.map((p) => p[0]);
			const ys = r.poly.map((p) => p[1]);
			const x = (Math.min(...xs) + Math.max(...xs)) / 2;
			const y = (Math.min(...ys) + Math.max(...ys)) / 2;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
				position: [
					wx(x),
					CEILING - .35,
					wz(y)
				],
				intensity: 11,
				distance: 7,
				decay: 2,
				color: "#ffd7a8"
			}, r.id);
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.03,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [48, 48] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: night ? "#2a3036" : "#d4cec2",
				roughness: 1
			})]
		})
	] });
}
function poseFor(mode, id) {
	let t = new Vector3(0, .35, 0);
	let dist = 16.2;
	if (id && id !== "all") {
		const r = ROOMS.find((room) => room.id === id);
		if (r) {
			const xs = r.poly.map((p) => p[0]);
			const ys = r.poly.map((p) => p[1]);
			const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
			const cy = (Math.min(...ys) + Math.max(...ys)) / 2;
			t = new Vector3(wx(cx), .4, wz(cy));
			dist = Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)) / 1e3 * 1.2 + 2.6;
		}
	}
	if (mode === "top") return {
		p: new Vector3(t.x, id && id !== "all" ? dist : 18, t.z + .02),
		t
	};
	const dir = new Vector3(.58, .74, .48).normalize();
	return {
		p: t.clone().addScaledVector(dir, dist),
		t
	};
}
function CameraDirector() {
	const mode = usePlan((s) => s.mode);
	const focus = usePlan((s) => s.focus);
	const camera = useThree((s) => s.camera);
	const controls = useThree((s) => s.controls);
	const anim = (0, import_react.useRef)(null);
	const key = `${mode}:${focus?.n ?? 0}:${focus?.id ?? "all"}`;
	const seen = (0, import_react.useRef)("");
	useFrame((_, raw) => {
		const dt = Math.min(raw, .05);
		if (mode === "walk") {
			anim.current = null;
			return;
		}
		if (seen.current !== key && controls) {
			seen.current = key;
			const pose = poseFor(mode === "top" ? "top" : "orbit", focus?.id ?? null);
			const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			anim.current = {
				t: 0,
				dur: reduce ? .01 : .85,
				fromP: camera.position.clone(),
				toP: pose.p,
				fromT: controls.target.clone(),
				toT: pose.t
			};
			camera.fov = 42;
			camera.updateProjectionMatrix();
		}
		const a = anim.current;
		if (!a || !controls) return;
		a.t += dt;
		const u = Math.min(1, a.t / a.dur);
		const e = u < .5 ? 4 * u * u * u : 1 - (-2 * u + 2) ** 3 / 2;
		camera.position.lerpVectors(a.fromP, a.toP, e);
		controls.target.lerpVectors(a.fromT, a.toT, e);
		if (u >= 1) anim.current = null;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
		makeDefault: true,
		enabled: mode !== "walk",
		enableDamping: true,
		dampingFactor: .12,
		maxPolarAngle: Math.PI / 2 - .04,
		minDistance: 1.1,
		maxDistance: 30,
		target: [
			0,
			.35,
			0
		]
	});
}
function WalkRig() {
	const mode = usePlan((s) => s.mode);
	const camera = useThree((s) => s.camera);
	const gl = useThree((s) => s.gl);
	const scene = useThree((s) => s.scene);
	const yaw = (0, import_react.useRef)(0);
	const pitch = (0, import_react.useRef)(-.08);
	const pos = (0, import_react.useRef)({
		x: wx(SPAWN[0]),
		z: wz(SPAWN[1])
	});
	const keys = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const override = (0, import_react.useRef)(null);
	const speed = (0, import_react.useRef)(0);
	const prevE = (0, import_react.useRef)(false);
	const ray = (0, import_react.useRef)(new Raycaster());
	const dragging = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const down = (e) => {
			override.current = null;
			keys.current.add(e.code);
			if ([
				"ArrowUp",
				"ArrowDown",
				"ArrowLeft",
				"ArrowRight",
				"Space"
			].includes(e.code)) e.preventDefault();
		};
		const up = (e) => keys.current.delete(e.code);
		const blur = () => keys.current.clear();
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", blur);
		return () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", blur);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const el = gl.domElement;
		const coarse = window.matchMedia("(pointer: coarse)").matches;
		const onClick = () => {
			if (usePlan.getState().mode !== "walk" || coarse) return;
			if (document.pointerLockElement !== el) el.requestPointerLock();
		};
		const onMove = (e) => {
			if (document.pointerLockElement !== el) return;
			yaw.current -= e.movementX * .0022;
			pitch.current -= e.movementY * .0022;
			pitch.current = Math.max(-1.15, Math.min(1.15, pitch.current));
		};
		const onDown = (e) => {
			if (usePlan.getState().mode !== "walk") return;
			if (!coarse && document.pointerLockElement === el) return;
			dragging.current = {
				x: e.clientX,
				y: e.clientY
			};
		};
		const onDrag = (e) => {
			if (!dragging.current || usePlan.getState().mode !== "walk") return;
			const dx = e.clientX - dragging.current.x;
			const dy = e.clientY - dragging.current.y;
			dragging.current = {
				x: e.clientX,
				y: e.clientY
			};
			if (document.pointerLockElement === el) return;
			yaw.current -= dx * .005;
			pitch.current -= dy * .005;
			pitch.current = Math.max(-1.15, Math.min(1.15, pitch.current));
		};
		const onUp = () => {
			dragging.current = null;
		};
		el.addEventListener("click", onClick);
		document.addEventListener("mousemove", onMove);
		el.addEventListener("pointerdown", onDown);
		el.addEventListener("pointermove", onDrag);
		window.addEventListener("pointerup", onUp);
		return () => {
			el.removeEventListener("click", onClick);
			document.removeEventListener("mousemove", onMove);
			el.removeEventListener("pointerdown", onDown);
			el.removeEventListener("pointermove", onDrag);
			window.removeEventListener("pointerup", onUp);
		};
	}, [gl]);
	(0, import_react.useEffect)(() => {
		window.__controlsTest = {
			getYaw: () => yaw.current,
			getSpeed: () => speed.current,
			getPos: () => ({
				x: pos.current.x,
				z: pos.current.z
			}),
			setKeys: (codes) => {
				override.current = new Set(codes);
			},
			setYaw: (v) => {
				yaw.current = v;
			},
			setPos: (x, z) => {
				pos.current.x = x;
				pos.current.z = z;
			}
		};
		return () => {
			if (window.__controlsTest?.getYaw === window.__controlsTest?.getYaw) delete window.__controlsTest;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (mode !== "walk") {
			if (document.pointerLockElement === gl.domElement) document.exitPointerLock();
			return;
		}
		pos.current = {
			x: wx(SPAWN[0]),
			z: wz(SPAWN[1])
		};
		yaw.current = 0;
		pitch.current = -.06;
		camera.fov = 68;
		camera.updateProjectionMatrix();
	}, [
		mode,
		camera,
		gl
	]);
	useFrame((_, raw) => {
		const dt = Math.min(raw, .05);
		if (mode !== "walk") {
			speed.current = 0;
			return;
		}
		const held = override.current ?? keys.current;
		const stick = usePlan.getState().stick;
		let sx = (held.has("KeyD") || held.has("ArrowRight") ? 1 : 0) - (held.has("KeyA") || held.has("ArrowLeft") ? 1 : 0);
		let sy = (held.has("KeyW") || held.has("ArrowUp") ? 1 : 0) - (held.has("KeyS") || held.has("ArrowDown") ? 1 : 0);
		sx += stick.x;
		sy += stick.y;
		const mag = Math.hypot(sx, sy);
		if (mag > 1) {
			sx /= mag;
			sy /= mag;
		}
		const run = held.has("ShiftLeft") || held.has("ShiftRight") ? 2.35 : 1.4;
		const yv = yaw.current;
		const fx = -Math.sin(yv);
		const fz = -Math.cos(yv);
		const rx = Math.cos(yv);
		const rz = -Math.sin(yv);
		const dx = (fx * sy + rx * sx) * run * dt;
		const dz = (fz * sy + rz * sx) * run * dt;
		const doors = usePlan.getState().doors;
		const r = .18;
		let nx = pos.current.x + dx;
		let nz = pos.current.z + dz;
		if (blocked(nx, pos.current.z, r, doors)) nx = pos.current.x;
		if (blocked(nx, nz, r, doors)) nz = pos.current.z;
		speed.current = Math.hypot(nx - pos.current.x, nz - pos.current.z) / Math.max(dt, 1e-4);
		pos.current.x = nx;
		pos.current.z = nz;
		camera.position.set(nx, EYE, nz);
		camera.rotation.order = "YXZ";
		camera.rotation.y = yv;
		camera.rotation.x = pitch.current;
		const eDown = held.has("KeyE");
		if (eDown && !prevE.current) {
			ray.current.setFromCamera(new Vector2(0, 0), camera);
			const hit = ray.current.intersectObjects(scene.children, true).find((h) => h.object.userData.doorId && h.distance < 2.4);
			if (hit) usePlan.getState().toggleDoor(hit.object.userData.doorId);
		}
		prevE.current = eDown;
	});
	return null;
}
function Stage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		className: "h-full w-full",
		shadows: false,
		onCreated: ({ gl }) => {
			gl.shadowMap.enabled = true;
			gl.shadowMap.type = 1;
		},
		dpr: [1, 1.6],
		camera: {
			position: [
				7.2,
				11.5,
				8.4
			],
			fov: 42,
			near: .06,
			far: 80
		},
		gl: {
			antialias: true,
			toneMapping: 4,
			toneMappingExposure: 1.05
		},
		onPointerMissed: () => usePlan.getState().select(null),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lighting, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraDirector, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalkRig, {})
		]
	});
}
//#endregion
export { Stage };
