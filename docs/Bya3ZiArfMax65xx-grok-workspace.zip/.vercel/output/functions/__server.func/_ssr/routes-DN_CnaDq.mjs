import { i as __toESM } from "../_runtime.mjs";
import { g as require_react, h as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DN_CnaDq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var CEILING = 2.7;
var EYE = 1.58;
var ROOMS = [
	{
		id: "A",
		name: "卧室 A",
		zone: "bed",
		label: 14.3,
		floor: "#e4d0ae",
		poly: [
			[2707, 288],
			[4938, 288],
			[4938, 1074],
			[5365, 1074],
			[5365, 6116],
			[4246, 6116],
			[4246, 4547],
			[2263, 4547],
			[2263, 974],
			[2707, 974]
		],
		glass: [{
			edge: 0,
			sill: .45
		}],
		main: ["3100 × 3570", "主体东西 × 南北，约 11.1 ㎡"],
		facts: [
			{
				k: "北侧窗洞",
				v: "2235 × 690–790",
				exact: true
			},
			{
				k: "入门过道",
				v: "1120 × 1580"
			},
			{
				k: "最大进深",
				v: "5830（窗到门墙）"
			}
		],
		tip: "主体可放 1.8 × 2.0 m 床：床头靠西墙，东侧约留 1.0 m。南北放下床宽后还够 600 深衣柜。"
	},
	{
		id: "B",
		name: "卧室 B",
		zone: "bed",
		label: 11,
		floor: "#dcc4a0",
		poly: [
			[325, 4121],
			[2136, 4121],
			[2136, 4674],
			[4117, 4674],
			[4117, 7549],
			[2586, 7549],
			[2586, 7927],
			[1009, 7927],
			[1009, 5355],
			[325, 5355]
		],
		glass: [{
			edge: 0,
			sill: .45
		}, {
			edge: 9,
			sill: .45
		}],
		main: ["3110 × 2870", "主体东西 × 南北，约 8.9 ㎡"],
		facts: [
			{
				k: "北窗段",
				v: "1811 × 560",
				exact: true
			},
			{
				k: "西南段",
				v: "1581",
				exact: true
			},
			{
				k: "最大进深",
				v: "3810（北窗到南墙）"
			}
		],
		tip: "南北 2870 是瓶颈。模型里放了 1.5 m 宽的床，床头靠西；东墙门北侧放书桌。1.8 m 床再加衣柜会很挤。"
	},
	{
		id: "C",
		name: "卧室 C",
		zone: "bed",
		label: 6.8,
		floor: "#e7d6b8",
		poly: [
			[2705, 7678],
			[5415, 7678],
			[5415, 10199],
			[2705, 10199]
		],
		glass: [{
			edge: 3,
			sill: .9
		}],
		main: ["2710 × 2520", "东西（窗到墙）× 南北"],
		facts: [{
			k: "形状",
			v: "规整矩形"
		}, {
			k: "西墙",
			v: "整面为窗"
		}],
		tip: "适合 1.2 m 床加书桌。1.5 m 床横放后南北只剩约 1 m，再放衣柜通道就不够了。"
	},
	{
		id: "Bath",
		name: "卫生间",
		zone: "wet",
		label: 4.3,
		floor: "#d5ddd8",
		poly: [
			[2813, 10323],
			[5415, 10323],
			[5415, 11990],
			[2813, 11990]
		],
		glass: [],
		main: ["2600 × 1670", "东西 × 南北"],
		facts: [{
			k: "北墙墙垛",
			v: "130 × 660"
		}, {
			k: "墙垛分出",
			v: "西 1470 ｜ 东 1000"
		}],
		tip: "墙垛以东约 1000 宽，做了 900 × 900 淋浴。西侧留给马桶和台盆。门是推拉，不占室内。"
	},
	{
		id: "K",
		name: "厨房",
		zone: "wet",
		label: 7.3,
		floor: "#ddd6c8",
		poly: [
			[9030, 9988],
			[10374, 9988],
			[10374, 14434],
			[8728, 14434],
			[8728, 13801],
			[8328, 13801],
			[8328, 12114],
			[9030, 12114]
		],
		glass: [{
			edge: 0,
			sill: 1
		}],
		main: ["东墙通长 4450", "北窗到南墙"],
		facts: [
			{
				k: "北段",
				v: "1348 × 2130",
				exact: true
			},
			{
				k: "中段",
				v: "2050 × 1690"
			},
			{
				k: "南段",
				v: "1649 × 640",
				exact: true
			}
		],
		tip: "东墙做了一字台面。北段柜深 600 后通道只剩约 750，低于常用的 800–900。冰箱放在南端。"
	},
	{
		id: "L",
		name: "客厅",
		zone: "live",
		label: 29.7,
		floor: "#e5e0d4",
		poly: [
			[5993, 5473],
			[8523, 5473],
			[8523, 6252],
			[8906, 6252],
			[8906, 11990],
			[8219, 11990],
			[8219, 13801],
			[6818, 13801],
			[6818, 14484],
			[5509, 14484],
			[5509, 14200],
			[5013, 14200],
			[5013, 12113],
			[5542, 12113],
			[5542, 7550],
			[4239, 7550],
			[4239, 6233],
			[5993, 6233]
		],
		glass: [{
			edge: 0,
			sill: .45
		}, {
			edge: 11,
			sill: .85
		}],
		main: ["3360 × 5740", "主体东西 × 南北，约 19.3 ㎡"],
		facts: [
			{
				k: "北窗段",
				v: "2532 × 760",
				exact: true
			},
			{
				k: "北侧通道",
				v: "4670 × 1320"
			},
			{
				k: "玄关入户",
				v: "1316",
				exact: true
			},
			{
				k: "总进深",
				v: "8330（北窗到南墙）"
			}
		],
		tip: "开间 3360：沙发约 0.9 m、电视柜约 0.4 m，观看距离约 2.0 m，适合 55–65 寸。六扇门都朝向这个空间。"
	}
];
/** Plumbing pier inside the bathroom, millimetres [x0, y0, x1, y1]. */
var BATH_STUB = [
	4287,
	10323,
	4415,
	10993
];
var DOORS = [
	{
		id: "M1",
		name: "入户门",
		kind: "swing",
		axis: "h",
		j: [5620, 6414.2],
		w: [14483.6, 14705.9],
		into: -1,
		width: 794,
		where: "南外墙 · 玄关",
		how: "平开 · 向内 · 铰链在东",
		tip: "图上洞宽和卧室门几乎一样，更像统一门图块，订门前要现场量洞口。",
		head: 2.2
	},
	{
		id: "M2",
		name: "厨房门",
		kind: "slide",
		axis: "v",
		j: [12252.2, 13646.2],
		w: [8218.7, 8328.1],
		width: 1394,
		where: "厨房西侧 · 通客厅",
		how: "推拉 · 两扇",
		tip: "全屋最宽的门洞。打开后厨房中段和客厅南段基本连通。",
		head: 2.2
	},
	{
		id: "M3",
		name: "卫生间门",
		kind: "slide",
		axis: "v",
		j: [10974.2, 11869.7],
		w: [5415.3, 5541.9],
		width: 895,
		where: "卫生间东墙南端",
		how: "推拉 · 两扇",
		tip: "不占卫生间内部。门北侧约 650 是东墙上仅有的靠墙位置。",
		head: 2.1
	},
	{
		id: "M4",
		name: "卧室 C 门",
		kind: "swing",
		axis: "h",
		j: [4465.8, 5264.4],
		w: [7549.5, 7677.8],
		into: 1,
		width: 799,
		where: "卧室 C 北墙东端",
		how: "平开 · 向室内 · 铰链在东",
		tip: "开启扇区占东北角约 0.8 m。西侧北墙约 1.75 m，模型里放了书桌。",
		head: 2.05
	},
	{
		id: "M5",
		name: "卧室 B 门",
		kind: "swing",
		axis: "v",
		j: [6374.3, 7173.1],
		w: [4116.8, 4239.3],
		into: -1,
		width: 799,
		where: "卧室 B 东墙南段",
		how: "平开 · 向室内 · 铰链在南",
		tip: "门北侧东墙约 1.7 m。门扇向室内开，占东南角。",
		head: 2.05
	},
	{
		id: "M6",
		name: "卧室 A 门",
		kind: "swing",
		axis: "h",
		j: [4393.1, 5187],
		w: [6116, 6232.9],
		into: -1,
		width: 794,
		where: "卧室 A 过道南端",
		how: "平开 · 向室内 · 铰链在东",
		tip: "开在 1120 宽的入门过道里，不占卧室主体。",
		head: 2.05
	}
];
var FURNITURE = [
	{
		id: "a-bed",
		type: "bed",
		name: "1.8 m 床",
		room: "A",
		cx: 3313,
		cy: 2074,
		w: 1800,
		d: 2e3,
		rot: 270,
		color: "#c5d0d8"
	},
	{
		id: "a-ward",
		type: "wardrobe",
		name: "衣柜",
		room: "A",
		cx: 3200,
		cy: 4247,
		w: 1800,
		d: 600,
		rot: 180,
		color: "#efe6d6"
	},
	{
		id: "b-bed",
		type: "bed",
		name: "1.5 m 床",
		room: "B",
		cx: 2009,
		cy: 6200,
		w: 1500,
		d: 1900,
		rot: 270,
		color: "#d4c4d6"
	},
	{
		id: "b-desk",
		type: "desk",
		name: "书桌",
		room: "B",
		cx: 3842,
		cy: 5474,
		w: 1200,
		d: 550,
		rot: 90,
		color: "#e2cfb4"
	},
	{
		id: "c-bed",
		type: "bed",
		name: "1.2 m 床",
		room: "C",
		cx: 4375,
		cy: 9550,
		w: 1200,
		d: 2e3,
		rot: 90,
		color: "#e4d3b4"
	},
	{
		id: "c-desk",
		type: "desk",
		name: "书桌",
		room: "C",
		cx: 3405,
		cy: 7993,
		w: 1100,
		d: 550,
		rot: 0,
		color: "#e2cfb4"
	},
	{
		id: "c-chair",
		type: "chair",
		name: "椅子",
		room: "C",
		cx: 3405,
		cy: 8508,
		w: 450,
		d: 480,
		rot: 180,
		color: "#cfc6b8"
	},
	{
		id: "bath-sh",
		type: "shower",
		name: "淋浴",
		room: "Bath",
		cx: 4895,
		cy: 10793,
		w: 900,
		d: 900,
		rot: 0,
		color: "#d5e3ea"
	},
	{
		id: "bath-wc",
		type: "toilet",
		name: "马桶",
		room: "Bath",
		cx: 3600,
		cy: 11610,
		w: 400,
		d: 680,
		rot: 180,
		color: "#f4f7f8"
	},
	{
		id: "bath-van",
		type: "vanity",
		name: "台盆",
		room: "Bath",
		cx: 3073,
		cy: 10780,
		w: 800,
		d: 480,
		rot: 270,
		color: "#e7eef1"
	},
	{
		id: "k-cnt",
		type: "counter",
		name: "橱柜",
		room: "K",
		cx: 10074,
		cy: 11788,
		w: 3600,
		d: 600,
		rot: 90,
		color: "#e7e2d8"
	},
	{
		id: "k-fr",
		type: "fridge",
		name: "冰箱",
		room: "K",
		cx: 10020,
		cy: 14020,
		w: 700,
		d: 700,
		rot: 0,
		color: "#e4e8ea"
	},
	{
		id: "l-tv",
		type: "tvstand",
		name: "电视柜",
		room: "L",
		cx: 5742,
		cy: 10050,
		w: 2e3,
		d: 400,
		rot: 270,
		color: "#e2cfb4"
	},
	{
		id: "l-sofa",
		type: "sofa",
		name: "沙发",
		room: "L",
		cx: 8406,
		cy: 10050,
		w: 2300,
		d: 900,
		rot: 90,
		color: "#b7c4b0"
	},
	{
		id: "l-ct",
		type: "coffeetable",
		name: "茶几",
		room: "L",
		cx: 6949,
		cy: 10050,
		w: 1100,
		d: 600,
		rot: 0,
		color: "#e6dcc8"
	},
	{
		id: "l-rug",
		type: "rug",
		name: "地毯",
		room: "L",
		cx: 7200,
		cy: 10050,
		w: 2e3,
		d: 2800,
		rot: 0,
		color: "#d2c6b4"
	},
	{
		id: "l-plant",
		type: "plant",
		name: "绿植",
		room: "L",
		cx: 8520,
		cy: 7900,
		w: 460,
		d: 460,
		rot: 0,
		color: "#7ea36a"
	},
	{
		id: "l-table",
		type: "table",
		name: "餐桌",
		room: "L",
		cx: 7200,
		cy: 12800,
		w: 1200,
		d: 750,
		rot: 0,
		color: "#e2cfb4"
	},
	{
		id: "l-ch1",
		type: "chair",
		name: "餐椅",
		room: "L",
		cx: 7200,
		cy: 12185,
		w: 450,
		d: 480,
		rot: 0,
		color: "#cfc6b8"
	},
	{
		id: "l-ch2",
		type: "chair",
		name: "餐椅",
		room: "L",
		cx: 7200,
		cy: 13415,
		w: 450,
		d: 480,
		rot: 180,
		color: "#cfc6b8"
	}
];
/** Walk spawn, plan millimetres, inside the living room. */
var SPAWN = [7e3, 10880];
var openDoors = Object.fromEntries(DOORS.map((d) => [d.id, d.id === "M1" ? .35 : .72]));
var usePlan = create((set, get) => ({
	mode: "orbit",
	section: true,
	furniture: true,
	labels: true,
	night: false,
	hour: 11,
	selected: null,
	doors: openDoors,
	focus: null,
	stick: {
		x: 0,
		y: 0
	},
	setMode: (mode) => set({ mode }),
	toggleSection: () => set({ section: !get().section }),
	toggleFurniture: () => set({ furniture: !get().furniture }),
	toggleLabels: () => set({ labels: !get().labels }),
	toggleNight: () => set({ night: !get().night }),
	setHour: (hour) => set({ hour }),
	select: (id) => set({ selected: id }),
	focusRoom: (id) => set((s) => ({
		selected: id === "all" ? s.selected : id,
		focus: {
			id,
			n: (s.focus?.n ?? 0) + 1
		}
	})),
	toggleDoor: (id) => set((s) => ({ doors: {
		...s.doors,
		[id]: (s.doors[id] ?? 0) > .5 ? 0 : 1
	} })),
	setStick: (stick) => set({ stick })
}));
var EXT = 240;
var SEAL = 10;
function signedArea(p) {
	let a = 0;
	for (let i = 0; i < p.length; i++) {
		const [x1, y1] = p[i];
		const [x2, y2] = p[(i + 1) % p.length];
		a += x1 * y2 - x2 * y1;
	}
	return a / 2;
}
function outward(a, b, sa) {
	let nx = b[1] - a[1];
	let ny = -(b[0] - a[0]);
	const len = Math.hypot(nx, ny) || 1;
	nx /= len;
	ny /= len;
	if (sa < 0) {
		nx = -nx;
		ny = -ny;
	}
	return [nx, ny];
}
function edgesOf(room) {
	const poly = room.poly;
	const sa = signedArea(poly);
	const glass = new Map(room.glass.map((g) => [g.edge, g.sill]));
	const n = poly.length;
	const out = [];
	for (let i = 0; i < n; i++) {
		const a = poly[i];
		const b = poly[(i + 1) % n];
		const prev = poly[(i - 1 + n) % n];
		const next = poly[(i + 2) % n];
		const dx = b[0] - a[0];
		const dy = b[1] - a[1];
		if (Math.hypot(dx, dy) < 20) continue;
		const axis = Math.abs(dy) < 2 ? "h" : "v";
		if (axis === "h" && Math.abs(dy) >= 2) continue;
		if (axis === "v" && Math.abs(dx) >= 2) continue;
		const [nx, ny] = outward(a, b, sa);
		const cross = (c, d, e) => (d[0] - c[0]) * (e[1] - d[1]) - (d[1] - c[1]) * (e[0] - d[0]);
		const convexStart = cross(prev, a, b) * sa > 50;
		const convexEnd = cross(a, b, next) * sa > 50;
		const along0 = axis === "h" ? a[0] : a[1];
		const along1 = axis === "h" ? b[0] : b[1];
		const fixed = axis === "h" ? a[1] : a[0];
		const dir = axis === "h" ? ny : nx;
		out.push({
			room: room.id,
			axis,
			fixed,
			a0: Math.min(along0, along1),
			a1: Math.max(along0, along1),
			out: dir >= 0 ? 1 : -1,
			glass: glass.has(i),
			sill: glass.get(i) ?? .9,
			convex0: along0 < along1 ? convexStart : convexEnd,
			convex1: along0 < along1 ? convexEnd : convexStart
		});
	}
	return out;
}
function areaM2(poly) {
	return Math.abs(signedArea(poly)) / 1e6;
}
function bboxOf(rooms) {
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const r of rooms) for (const [x, y] of r.poly) {
		minX = Math.min(minX, x);
		minY = Math.min(minY, y);
		maxX = Math.max(maxX, x);
		maxY = Math.max(maxY, y);
	}
	return {
		minX,
		minY,
		maxX,
		maxY
	};
}
var BBOX = bboxOf(ROOMS);
var OX = (BBOX.minX + BBOX.maxX) / 2;
var OY = (BBOX.minY + BBOX.maxY) / 2;
var wx = (x) => (x - OX) / 1e3;
var wz = (y) => (y - OY) / 1e3;
function planArea(id) {
	const r = ROOMS.find((room) => room.id === id);
	return r ? areaM2(r.poly) : 0;
}
function subtract(p, o0, o1) {
	const next = [];
	if (p.a0 < o0 - 1) next.push({
		...p,
		a1: Math.min(p.a1, o0),
		convex1: false
	});
	if (p.a1 > o1 + 1) next.push({
		...p,
		a0: Math.max(p.a0, o1),
		convex0: false
	});
	return next.filter((q) => q.a1 - q.a0 > 25);
}
function pairPieces(pieces, minDist, maxDist, makeWall, walls) {
	let guard = 0;
	while (guard++ < 400) {
		let best = null;
		for (let i = 0; i < pieces.length; i++) for (let j = i + 1; j < pieces.length; j++) {
			const a = pieces[i];
			const b = pieces[j];
			if (a.axis !== b.axis || a.out === b.out || a.room === b.room) continue;
			const dist = (b.fixed - a.fixed) * a.out;
			if (dist < minDist || dist > maxDist) continue;
			const o0 = Math.max(a.a0, b.a0);
			const o1 = Math.min(a.a1, b.a1);
			const len = o1 - o0;
			if (len < 50) continue;
			if (!best || len > best.len) best = {
				i,
				j,
				o0,
				o1,
				len
			};
		}
		if (!best) break;
		const a = pieces[best.i];
		const b = pieces[best.j];
		if (makeWall) {
			const f0 = Math.min(a.fixed, b.fixed) - SEAL;
			const f1 = Math.max(a.fixed, b.fixed) + SEAL;
			walls.push({
				id: `int-${walls.length}`,
				axis: a.axis,
				a0: best.o0,
				a1: best.o1,
				f0,
				f1,
				kind: "int",
				openings: []
			});
		}
		const next = [];
		pieces.forEach((p, idx) => {
			if (idx === best.i || idx === best.j) next.push(...subtract(p, best.o0, best.o1));
			else next.push(p);
		});
		pieces = next;
	}
	return pieces;
}
function exteriorOf(p, index) {
	const t = EXT;
	let a0 = p.a0;
	let a1 = p.a1;
	if (p.convex0) a0 -= t;
	if (p.convex1) a1 += t;
	const f0 = p.out > 0 ? p.fixed - SEAL : p.fixed - t;
	const f1 = p.out > 0 ? p.fixed + t : p.fixed + SEAL;
	const openings = [];
	if (p.glass && p.a1 - p.a0 > 420) {
		const jamb = Math.min(180, (p.a1 - p.a0) * .12);
		openings.push({
			a0: p.a0 + jamb,
			a1: p.a1 - jamb,
			kind: "window",
			sill: p.sill,
			head: 2.15
		});
	}
	return {
		id: `ext-${index}`,
		axis: p.axis,
		a0,
		a1,
		f0,
		f1,
		kind: "ext",
		openings
	};
}
function overlap(a0, a1, b0, b1) {
	return Math.min(a1, b1) - Math.max(a0, b0);
}
function attachDoors(walls) {
	for (const door of DOORS) {
		const j0 = Math.min(door.j[0], door.j[1]);
		const j1 = Math.max(door.j[0], door.j[1]);
		const w0 = Math.min(door.w[0], door.w[1]);
		const w1 = Math.max(door.w[0], door.w[1]);
		let best = null;
		for (const wall of walls) {
			if (wall.axis !== door.axis || wall.kind === "stub") continue;
			const along = overlap(wall.a0, wall.a1, j0, j1);
			const thick = overlap(wall.f0, wall.f1, w0, w1);
			if (along < door.width * .62 || thick < 40) continue;
			const score = along + thick;
			if (!best || score > best.score) best = {
				wall,
				score
			};
		}
		if (!best) continue;
		const wall = best.wall;
		const a0 = Math.max(wall.a0, j0);
		const a1 = Math.min(wall.a1, j1);
		wall.openings = wall.openings.filter((o) => overlap(o.a0, o.a1, a0, a1) < 30);
		wall.openings.push({
			a0,
			a1,
			kind: "door",
			sill: 0,
			head: door.head,
			doorId: door.id
		});
	}
}
function buildWalls() {
	let pieces = ROOMS.flatMap(edgesOf);
	const walls = [];
	pieces = pairPieces(pieces, 60, 300, true, walls);
	pieces = pairPieces(pieces, -8, 60, false, walls);
	pieces.forEach((p, i) => {
		if (p.a1 - p.a0 < 40) return;
		walls.push(exteriorOf(p, i));
	});
	const [sx0, sy0, sx1, sy1] = BATH_STUB;
	walls.push({
		id: "stub",
		axis: "v",
		a0: sy0,
		a1: sy1,
		f0: sx0,
		f1: sx1,
		kind: "stub",
		openings: []
	});
	attachDoors(walls);
	return walls;
}
function collidersFrom(walls) {
	return walls.map((wall) => {
		const x0 = wx(wall.axis === "h" ? wall.a0 : wall.f0);
		const x1 = wx(wall.axis === "h" ? wall.a1 : wall.f1);
		const z0 = wz(wall.axis === "h" ? wall.f0 : wall.a0);
		const z1 = wz(wall.axis === "h" ? wall.f1 : wall.a1);
		const holes = wall.openings.filter((o) => o.kind === "door" && o.doorId).map((o) => {
			const hx0 = wx(wall.axis === "h" ? o.a0 : wall.f0);
			const hx1 = wx(wall.axis === "h" ? o.a1 : wall.f1);
			const hz0 = wz(wall.axis === "h" ? wall.f0 : o.a0);
			const hz1 = wz(wall.axis === "h" ? wall.f1 : o.a1);
			return {
				x0: Math.min(hx0, hx1),
				x1: Math.max(hx0, hx1),
				z0: Math.min(hz0, hz1),
				z1: Math.max(hz0, hz1),
				id: o.doorId
			};
		});
		return {
			x0: Math.min(x0, x1),
			x1: Math.max(x0, x1),
			z0: Math.min(z0, z1),
			z1: Math.max(z0, z1),
			holes
		};
	});
}
/** Leaf local +X aims along (dx, dy) in plan when rotation.y = this angle. */
function angleForPlanDir(dx, dy) {
	const len = Math.hypot(dx, dy) || 1;
	return Math.atan2(-dy / len, dx / len);
}
function doorMotion(door) {
	const across = (door.w[0] + door.w[1]) / 2;
	const hinge = door.axis === "h" ? [door.j[1], across] : [across, door.j[1]];
	const into = door.into ?? -1;
	const closed = door.axis === "h" ? {
		dx: door.j[0] - door.j[1],
		dy: 0
	} : {
		dx: 0,
		dy: door.j[0] - door.j[1]
	};
	const open = door.axis === "h" ? {
		dx: 0,
		dy: into
	} : {
		dx: into,
		dy: 0
	};
	let closedA = angleForPlanDir(closed.dx, closed.dy);
	let openA = angleForPlanDir(open.dx, open.dy);
	while (openA - closedA > Math.PI) openA -= Math.PI * 2;
	while (closedA - openA > Math.PI) openA += Math.PI * 2;
	return {
		hinge,
		closed: closedA,
		open: openA
	};
}
var cached = null;
function walls() {
	if (!cached) cached = buildWalls();
	return cached;
}
var MODES = [
	{
		id: "orbit",
		label: "鸟瞰"
	},
	{
		id: "top",
		label: "俯视"
	},
	{
		id: "walk",
		label: "漫游"
	}
];
function Stick() {
	const setStick = usePlan((s) => s.setStick);
	const origin = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const apply = (clientX, clientY) => {
		if (!origin.current) return;
		const dx = clientX - origin.current.x;
		const dy = clientY - origin.current.y;
		const max = 46;
		const x = Math.max(-1, Math.min(1, dx / max));
		const y = Math.max(-1, Math.min(1, -dy / max));
		setStick({
			x,
			y
		});
		setKnob({
			x: x * max,
			y: -y * max
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-28 w-28 touch-none rounded-full border border-muted/30 bg-sheet/90",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			origin.current = {
				x: e.clientX,
				y: e.clientY
			};
			apply(e.clientX, e.clientY);
		},
		onPointerMove: (e) => apply(e.clientX, e.clientY),
		onPointerUp: () => {
			origin.current = null;
			setKnob({
				x: 0,
				y: 0
			});
			setStick({
				x: 0,
				y: 0
			});
		},
		onPointerCancel: () => {
			origin.current = null;
			setKnob({
				x: 0,
				y: 0
			});
			setStick({
				x: 0,
				y: 0
			});
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute top-1/2 left-1/2 h-11 w-11 rounded-full bg-ink",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "移动摇杆，上为前进"
		})]
	});
}
function Hud() {
	const mode = usePlan((s) => s.mode);
	const section = usePlan((s) => s.section);
	const furniture = usePlan((s) => s.furniture);
	const labels = usePlan((s) => s.labels);
	const night = usePlan((s) => s.night);
	const hour = usePlan((s) => s.hour);
	const selected = usePlan((s) => s.selected);
	const doors = usePlan((s) => s.doors);
	const [locked, setLocked] = (0, import_react.useState)(false);
	const [coarse, setCoarse] = (0, import_react.useState)(false);
	const room = ROOMS.find((r) => r.id === selected) ?? null;
	(0, import_react.useEffect)(() => {
		setCoarse(window.matchMedia("(pointer: coarse)").matches);
		const onLock = () => setLocked(document.pointerLockElement != null);
		document.addEventListener("pointerlockchange", onLock);
		const onKey = (e) => {
			if (e.repeat) return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			const plan = usePlan.getState();
			if (e.code === "Escape") {
				if (document.pointerLockElement) document.exitPointerLock();
				else if (plan.mode === "walk") plan.setMode("orbit");
				return;
			}
			const idx = [
				"Digit1",
				"Digit2",
				"Digit3",
				"Digit4",
				"Digit5",
				"Digit6"
			].indexOf(e.code);
			if (idx >= 0) {
				plan.focusRoom(ROOMS[idx].id);
				return;
			}
			if (e.code === "KeyF") plan.focusRoom("all");
			if (e.code === "KeyT") plan.setMode(plan.mode === "walk" ? "orbit" : "walk");
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("pointerlockchange", onLock);
			window.removeEventListener("keydown", onKey);
		};
	}, []);
	const total = ROOMS.reduce((sum, r) => sum + planArea(r.id), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 flex flex-col p-3 sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted",
							children: "净尺寸 · 三室一厅 · 上北下南"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-none font-semibold sm:text-4xl",
							children: "户型三维"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-md text-sm text-muted",
							children: "按复尺的内墙轮廓建的模型。拖动旋转，双击房间飞近，点门可以开关。"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto flex flex-wrap gap-2",
					children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `h-11 rounded-sm px-3 text-sm ${mode === m.id ? "bg-ink text-sheet" : "bg-sheet text-ink"}`,
						onClick: () => usePlan.getState().setMode(m.id),
						children: m.label
					}, m.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2 sm:mr-80",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `pointer-events-auto h-11 rounded-sm px-3 text-sm ${!section ? "bg-ink text-sheet" : "bg-sheet text-ink"}`,
						onClick: () => usePlan.getState().toggleSection(),
						children: section ? "剖切墙" : "全高墙"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `pointer-events-auto h-11 rounded-sm px-3 text-sm ${furniture ? "bg-ink text-sheet" : "bg-sheet text-ink"}`,
						onClick: () => usePlan.getState().toggleFurniture(),
						children: "家具"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `pointer-events-auto h-11 rounded-sm px-3 text-sm ${labels ? "bg-ink text-sheet" : "bg-sheet text-ink"}`,
						onClick: () => usePlan.getState().toggleLabels(),
						children: "标注"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `pointer-events-auto h-11 rounded-sm px-3 text-sm ${night ? "bg-ink text-sheet" : "bg-sheet text-ink"}`,
						onClick: () => usePlan.getState().toggleNight(),
						children: night ? "夜景" : "日光"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "pointer-events-auto flex h-11 items-center gap-2 rounded-sm bg-sheet px-3 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular",
							children: [String(Math.floor(hour)).padStart(2, "0"), ":00"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-24 accent-dim",
							type: "range",
							min: 6,
							max: 18,
							step: .5,
							value: hour,
							"aria-label": "日照时间",
							onChange: (e) => usePlan.getState().setHour(Number(e.target.value))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-4 flex-1" }),
			mode === "walk" && !locked && !coarse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none mb-3 self-center text-center text-sm text-ink",
				children: "点击画面锁定鼠标 · WASD 移动 · E 开关门 · Esc 退出"
			}) : null,
			mode === "walk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute bottom-4 left-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, {})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `pointer-events-auto absolute inset-x-3 bottom-3 max-h-[42dvh] overflow-auto rounded-sm border border-muted/25 bg-sheet/95 p-3 sm:inset-x-auto sm:top-36 sm:right-4 sm:bottom-4 sm:max-h-none sm:w-80 ${mode === "walk" ? "hidden" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 flex flex-wrap gap-1.5",
						children: DOORS.map((d) => {
							const open = (doors[d.id] ?? 0) > .5;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `h-9 rounded-sm px-2 text-xs ${open ? "bg-ink text-sheet" : "bg-paper text-ink"}`,
								onClick: () => usePlan.getState().toggleDoor(d.id),
								children: [
									d.id,
									" ",
									d.name,
									" ",
									open ? "开" : "关"
								]
							}, d.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-semibold",
							children: "房间"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted tabular",
							children: [
								"复算 ",
								total.toFixed(1),
								" ㎡"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2",
						children: ROOMS.map((r, i) => {
							const on = r.id === selected;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `w-full rounded-sm border px-3 py-2 text-left ${on ? "border-dim bg-dim/10" : "border-muted/20"}`,
								onClick: () => usePlan.getState().focusRoom(r.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-base font-semibold",
										children: r.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted tabular",
										children: [
											i + 1,
											" · ",
											r.label,
											" ㎡"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-dim tabular",
									children: r.main[0]
								})]
							}) }, r.id);
						})
					}),
					room ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2 border-t border-muted/20 pt-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: room.main[1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "grid grid-cols-[auto_1fr] gap-x-3 gap-y-1",
								children: room.facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "contents",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: f.k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "tabular",
										children: [f.v, f.exact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-xs text-muted",
											children: "原值"
										}) : null]
									})]
								}, f.k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: room.tip })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 border-t border-muted/20 pt-3 text-sm text-muted",
						children: "层高图上没有，这里按 2.70 m。窗台按常见住宅假定。单个尺寸大约 ±15 mm。平开门洞宽不宜直接拿去订门。"
					})
				]
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	const [Stage, setStage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let dead = false;
		import("./stage-BW0TusQF.mjs").then((mod) => {
			if (!dead) setStage(() => mod.Stage);
		});
		return () => {
			dead = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh overflow-hidden bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 touch-none bg-paper",
			children: Stage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {}) : null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {})]
	});
}
//#endregion
export { wx as a, CEILING as c, FURNITURE as d, ROOMS as f, walls as i, DOORS as l, collidersFrom as n, wz as o, SPAWN as p, doorMotion as r, usePlan as s, routes_exports as t, EYE as u };
